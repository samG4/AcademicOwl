package com.example.learning.sam.academicowl.Services;

/**
 * Created by 586333 on 12/4/2017.
 */
public class Constants {


    public interface ACTION {
        public static String MAIN_ACTION = "com.example.learning.sam.academicowl.services.foregroundobserveservice.action.main";
        public static String INIT_ACTION = "com.example.learning.sam.academicowl.services.foregroundobserveservice.action.init";
        public static String PREV_ACTION = "com.example.learning.sam.academicowl.services.foregroundobserveservice.action.prev";
        public static String PLAY_ACTION = "com.example.learning.sam.academicowl.services.foregroundobserveservice.action.play";
        public static String NEXT_ACTION = "com.example.learning.sam.academicowl.services.foregroundobserveservice.action.next";
        public static String STARTFOREGROUND_ACTION = "com.example.learning.sam.academicowl.services.foregroundobserveservice.action.startforeground";
        public static String STOPFOREGROUND_ACTION = "com.example.learning.sam.academicowl.services.foregroundobserveservice.action.stopforeground";
        public static boolean JOB_STARTED = true;
    }

    public interface NOTIFICATION_ID {
        public static int FOREGROUND_SERVICE = 101;
    }
}