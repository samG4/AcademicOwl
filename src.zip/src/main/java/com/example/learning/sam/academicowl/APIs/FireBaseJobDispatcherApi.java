package com.example.learning.sam.academicowl.APIs;

import android.content.Context;

import com.firebase.jobdispatcher.FirebaseJobDispatcher;
import com.firebase.jobdispatcher.GooglePlayDriver;

/**
 * Created by 586333 on 12/4/2017.
 */

public class FireBaseJobDispatcherApi {
   private static FireBaseJobDispatcherApi dispatcherApi = null;

    public FirebaseJobDispatcher getDispatcher() {
        return dispatcher;
    }

    private FirebaseJobDispatcher dispatcher;

    public FireBaseJobDispatcherApi getInstance(Context context){
        if(dispatcherApi == null)
            dispatcherApi = new FireBaseJobDispatcherApi();
        dispatcherApi.dispatcher = new FirebaseJobDispatcher(new GooglePlayDriver(context));
        return dispatcherApi;
    }
}
