package com.example.learning.sam.academicowl.Services;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.example.learning.sam.academicowl.APIs.FireBaseJobDispatcherApi;
import com.firebase.jobdispatcher.JobParameters;
import com.firebase.jobdispatcher.JobService;

import java.util.List;


public class AppStatusService extends JobService {
    private static AppStatusService job_instance = null;
    private boolean status;
    private static Context context;
    public static int end = 0;
    public AppStatusService(){

    }

    public boolean getStatus() {
        return status;
    }

    public static AppStatusService getInstance() {
        if (job_instance == null)
            job_instance = new AppStatusService();
        return job_instance;
    }
    public void setContext(Context context){
        this.context=context;
    }

    @Override
    public boolean onStartJob(JobParameters job) {
        Log.i("is App in BackGround: ", "" + isAppInBackground());
        if (Constants.ACTION.JOB_STARTED == false) {
            new FireBaseJobDispatcherApi().getDispatcher().cancel("AppStatusJob");
        }
        else
        {
            new AppStatusService().getInstance().status = isAppInBackground();
        }
        return false;
    }


    @Override
    public boolean onStopJob(JobParameters job) {
//        Log.i("END",end+"");
        return false;
    }

    boolean isAppInBackground() {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> appProcesses = activityManager.getRunningAppProcesses();
        if (appProcesses == null) {
            return true;
        }
        final String packageName = context.getPackageName();
        for (ActivityManager.RunningAppProcessInfo appProcess : appProcesses) {
            if (appProcess.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND && appProcess.processName.equals(packageName)) {
                return false;
            }
        }
        return true;
    }
}

