package com.example.learning.sam.academicowl.Services;

import android.util.Log;

import com.example.learning.sam.academicowl.APIs.ActivityRecognizedService;
import com.example.learning.sam.academicowl.APIs.FireBaseJobDispatcherApi;
import com.example.learning.sam.academicowl.Log.LogDatabaseHandler;
import com.example.learning.sam.academicowl.Log.LogTable;
import com.firebase.jobdispatcher.JobParameters;
import com.firebase.jobdispatcher.JobService;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Created by 586333 on 12/4/2017.
 */

public class UserPatternWRTService extends JobService {
    List<LogTable> logTables = new ArrayList<>();
    int id=0;
    public UserPatternWRTService(){

    }
    @Override
    public boolean onStartJob(JobParameters job) {
        LogTable log = new LogTable(id++, Calendar.getInstance().getTime(), ActivityRecognizedService.getInstance().getActivity());
        logTables.add(log);
        if (Constants.ACTION.JOB_STARTED == false) {
            new FireBaseJobDispatcherApi().getDispatcher().cancel("UserPatternJob");
        }
        else
        {
            Log.i("Data Collected","At this time "+log.get_system_time().toString()+" the activity is "+ log.get_activity());
            new LogDatabaseHandler(this.getBaseContext()).insertLog(log);
        }

        return false;
    }

    @Override
    public boolean onStopJob(JobParameters job) {
        return false;
    }
}
